Google Sitemap Lite
======================

This plugin create a (Google) sitemap based on the Structure/Taxonomy/Navee module. You can generate a sitemap for all content or only the pages (Structure).

More info about the plugin can be found on http://reinos.nl/add-ons/google-sitemap-lite