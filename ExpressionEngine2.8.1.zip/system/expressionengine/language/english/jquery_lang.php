<?php

$lang = array(

'jquery_module_name' =>
'jQuery',

'jquery_module_description' =>
'jQuery Module',

'missing_jquery_file' =>
'The requested jQuery file could not be found.',

''=>''
);

/* End of file jquery_lang.php */
/* Location: ./system/expressionengine/language/english/jquery_lang.php */