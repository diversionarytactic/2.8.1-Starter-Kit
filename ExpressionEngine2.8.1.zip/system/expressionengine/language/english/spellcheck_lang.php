<?php

$lang = array(

//----------------------------
// Publish page
//----------------------------

'spell_check' =>
'Spell Check',

'check_spelling' =>
'Check Spelling',

'save_spellcheck' =>
'Save Changes',

'revert_spellcheck' =>
'Revert to Original',

'spell_save_edit' =>
'Save Edit',

'spell_edit_word' =>
'Edit Word',

'unsupported_browser' =>
'Unsupported Browser',

'no_spelling_errors' =>
'No Errors Found',

'spellcheck_in_progress' =>
'Check In Progress...',


''=>''
);


/* End of file spellcheck_lang.php */
/* Location: ./system/expressionengine/language/english/spellcheck_lang.php */