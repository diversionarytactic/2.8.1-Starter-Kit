-------------------------------------------------------
INFO
-------------------------------------------------------

Structure for ExpressionEngine

Date modified    : 11.30.14
Current version  : 3.3.14.7

-------------------------------------------------------
REQUIREMENTS
-------------------------------------------------------

1. PHP5

!!!!!!!!!!!!!!!!   WARNING   !!!!!!!!!!!!!!!!

THE STRUCTURE EXTENSION AND MODULE CAN NOT BE INSTALLED
AT THE SAME TIME AS THE NATIVE EE PAGES MODULE!

-------------------------------------------------------
INSTALLATION
-------------------------------------------------------

1. Make sure the native EE Pages module is not installed, uninstall if not
2. Copy /structure/ to /system/expressionengine/third_party/ (or wherever you keep your third-party add-ons)
3. Copy /themes/third_party/structure/ to /themes/third_party/structure/
4. Install the add-on package from Add-ons » Modules

-------------------------------------------------------
UPGRADING
-------------------------------------------------------

1. Copy /structure/ to /system/expressionengine/third_party/ (or wherever you keep your third-party add-ons)
2. Copy /themes/third_party/structure/ to /themes/third_party/structure/
3. Make sure the extension is enabled

-------------------------------------------------------
DOCUMENTATION
-------------------------------------------------------

http://buildwithstructure.com

-------------------------------------------------------
CREDIT
-------------------------------------------------------

Travis Schmeisser

Email: travis@rockthenroll.com
Twitter: @rockthenroll
AIM: rockthenroll
Site: http://rockthenroll.com

----------------------------------------------
RESTRICTIONS
----------------------------------------------

Unless you have been granted prior, written consent from Travis Schmeisser, you may not:

- Reproduce, distribute, or transfer the Software, or portions thereof, to any third party
- Sell, rent, lease, assign, or sublet the Software or portions thereof
- Grant rights to any other person
- GPLv2 software has been used for the javascript in this module and do not carry to those portions