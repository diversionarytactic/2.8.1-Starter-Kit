<?php

DEFINE('BASEPATH',1);

include_once("/Users/padraig/Documents/Programming/Mountee/ExpressionEngine Modules/EE 2/mountee/libraries/EE_Cocoa.php");

$testvariable = array();

$testvariable[] = array("somejunk"=>"123", "otherjunk"=>"234");
$testvariable[] = array("somejunk"=>"123", "otherjunk"=>"234");
$testvariable[] = array("somejunk"=>"123", "otherjunk"=>"234");

echo json_encode($testvariable);

$cocoa = new EE_Cocoa();
print "\n";
echo $cocoa->generate_json_old($testvariable, true);
?>