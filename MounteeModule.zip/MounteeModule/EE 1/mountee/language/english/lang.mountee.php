<?php 

$L = array( 

'mountee_module_name'				=> 'Mountee',
'mountee_module_description'		=> 'Enables the Mountee interface to ExpressionEngine',
''=>''

);

 ?>