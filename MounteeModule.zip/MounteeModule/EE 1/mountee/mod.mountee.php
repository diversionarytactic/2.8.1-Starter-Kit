<?php      

Class Mountee {
	
	function Mountee()
    {
	       	
    }
    
}

?>