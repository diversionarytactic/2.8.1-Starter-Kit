<?php  

require("libraries/EE1_Cocoa.php"); 

class Mountee_CP extends EE1_Cocoa {
	var $VERSION = '2.3';
	var $DEFAULT_SITE_ID = 1; 		// can't use normal constants in PHP 4
	
	function Mountee_CP($switch=TRUE)
	{
		parent::EE1_Cocoa();
		
    	$this->data["filesync"] = (bool)($this->preferences->ini('save_tmpl_files')=='y');
		$this->DEFAULT_SITE_ID = $this->preferences->ini('site_id');
        global $IN; 
        		 
		// Execute whatever the command is
		
		
		$func = $IN->GBL('P');
		if ($func!="") {
			parent::_start();
			$this->$func();
	        parent::_finish();
		}

	}
	
	function mountee_module_install()
	{
		$sql[] = "
		INSERT INTO exp_modules
		 (module_name,module_version,has_cp_backend)	 
		VALUES 
		 ('Mountee', '$this->VERSION', 'n')";
				
		foreach ($sql as $query)
        {
            $this->DB->query($query);
        }
        
        return true;
	}
	
	function mountee_module_deinstall()
	{
		global $DB;
		
		$sql[] = "
		DELETE FROM exp_modules 
		WHERE  module_name = 'Mountee'";
		
		$sql[] = "
		DELETE FROM exp_actions 
		WHERE  class = 'Mountee'";
		
		foreach ($sql as $query)
		{
		    $this->DB->query($query);
		}
		
		return true;
	}
	
	function status()
	{
		$this->data["site_label"] = $this->preferences->ini('site_label');
		$this->data["base_url"] = $this->preferences->ini('site_url');
    	$this->data["success"] = True;
	}
	
	
	function list_all()
    {
    	$sql = "SELECT 	group_id,
						group_name, 
						is_site_default
				FROM 	exp_template_groups
				WHERE	site_id = ".$this->DEFAULT_SITE_ID;

		$group_query = $this->DB->query($sql); 
		$groups = $group_query->result;
			
		$this->data["groups"] = array();
		
		foreach($groups as $group_arr)
		{
			$group = (object)$group_arr;
			
			// Get the templates for each group
			$sql = "SELECT 	t.template_id,
							t.group_id,
							t.template_name,
							t.template_type,
							t.edit_date,
							t.cache,
							t.refresh,
							t.allow_php,
							t.php_parse_location,
							t.hits,
							t.template_data
					FROM	exp_templates t 
					JOIN	exp_template_groups g 	ON g.group_id = t.group_id
					WHERE	g.site_id = ".$this->DEFAULT_SITE_ID."
					AND		g.group_id = ".$group->group_id;
					
			$template_query = $this->DB->query($sql); 
			$results = $template_query->result;			
			
			$templates = array();
			
			foreach($results as $template) 
			{
				$template = (object)$template;
				$templates[] = array(	"id" 				=> (int)$template->template_id,
										"name" 				=> $template->template_name,
										"type"				=> $template->template_type,
										"last_modified" 	=> (int)$template->edit_date,
										"should_cache"  	=> (bool)($template->cache =="y"),
										"cache_refresh"		=> (int)$template->refresh,										
										"allow_php"  		=> (bool)($template->allow_php =="y"),
										"php_parse_output"	=> (bool)($template->php_parse_location =="o"),												
										"hits"				=> (int)$template->hits,
										"data"				=> base64_encode($template->template_data)
									);
			}
				
			$this->data["groups"][] = array("id" => (int)$group->group_id,
											"name" => $group->group_name,
											"templates" => $templates 
											);
			

			if($group->is_site_default=="y")
			{
				$this->data["index"] = (int)$group->group_id;
			}
		}

		// No snippets in EE1
		$this->data["snippets"] = False;
					
		// Get Global Variables
							
		$sql = "SELECT 	variable_id,
						variable_name,
						variable_data
				FROM	exp_global_variables 
				WHERE	site_id = ".$this->DEFAULT_SITE_ID;
				
		$var_query = $this->DB->query($sql); 
		$results = $var_query->result;
		
		$variables = array();
		
		foreach($results as $variable)
		{
			$variable = (object)$variable;
			
			$variables[] = array(	"id" 				=> (int)$variable->variable_id,
									"name" 				=> $variable->variable_name,
									"data"				=> base64_encode($variable->variable_data)
								);
		}
		
		$this->data["variables"] = $variables;
		$this->data["success"] = True;
    }
    
    ///! Snippets
    function list_snippets()
    {
    	$this->data["snippets"] = False;
    	$this->data["success"] = True;
    }

    ///! Global Variables
       
    function list_variables()
    {
    	$sql = "SELECT 	variable_id,
						variable_name,
						variable_data
				FROM	exp_global_variables 
				WHERE	site_id = ".$this->DEFAULT_SITE_ID;
				
		$var_query = $this->DB->query($sql); 
		$results = $var_query->result;
		
		$variables = array();
		
		foreach($results as $variable)
		{
			$variable = (object)$variable;
			
			$variables[] = array(	"id" 				=> (int)$variable->variable_id,
									"name" 				=> $variable->variable_name,
									"data"				=> base64_encode($variable->variable_data)
								);
		}
		
		$this->data["variables"] = $variables;
		$this->data["success"] = True;

    }
       
    function api_create_variable($instructions) 
   	{	
    	$data = array(	'site_id' 			=> $this->DEFAULT_SITE_ID,
    					'variable_name'		=> $this->escape_str($instructions->name),
						'variable_data'		=> "");
    	
    	
    	$this->DB->query($this->_build_insert($data, "exp_global_variables"));
    	
    	$this->data["success"] = True;
    	
    	$this->_variable_data($this->DB->insert_id);
   	}
   	
   	function read_variable_data($instructions)
   	{
   		$this->_variable_data($this->input->GBL('variable_id'));
   	}
   	
   	function api_update_variable($instructions)
    {		
		$data = str_replace("\\","", $instructions->data);
		$data = str_replace(" ","+",$data);		
		$decoded = base64_decode($data);
		
		$sql = "
		UPDATE 	exp_global_variables
		SET		variable_data = '".$this->escape_str($decoded)."'
		WHERE 	variable_id	  =  ".$instructions->variable_id;
		
		$this->DB->query($sql);
		
		$this->functions->clear_caching('all');				
		
		$this->data["success"] = True;
		
		$this->_variable_data($instructions->variable_id);
    }
    
    function _variable_data($id)
    {
    	$sql = "SELECT 	v.variable_id,
    					v.variable_data,
						v.variable_name
				FROM	exp_global_variables v 
				WHERE	v.site_id = ".$this->DEFAULT_SITE_ID."
				AND		v.variable_id = ".$this->escape_str($id);

		$query = $this->DB->query($sql); 	
		
		if($query->num_rows==0)
		{
			$this->data["variable"] = False;
			$this->data["success"]  = False;
		} 
		
		else 
		{			
			$variable = (object)$query->result[0];
			
			$this->data["variable"] 	= array("id" 				=> (int)$variable->variable_id,
												"name" 				=> $variable->variable_name,
												"data"				=> base64_encode($variable->variable_data)
												);	
			$this->data["success"] = True;												
		}
    }
    
    function api_delete_variable($instructions)
    {
    	$sql = "DELETE FROM exp_global_variables WHERE variable_id = ".$instructions->variable_id;
    	$this->DB->query($sql);
    	$this->data["success"] = $this->DB->affected_rows != 0;
    	$this->functions->clear_caching('all');
    }
    
    function api_rename_variable($instructions)
    {
	    $sql = "
	    UPDATE 	exp_global_variables
	    SET		variable_name = '".$this->escape_str($instructions->name)."'
	    WHERE 	variable_id	  =  ".$instructions->variable_id;
	    
	    $this->DB->query($sql);
	    
		$this->functions->clear_caching('all');
		
		$this->data["success"] = True;
    }
    
    ///! Template Preferences
    
    function api_set_hits($instructions) 
    {
    
	    $sql = "
	    UPDATE 	exp_templates
	    SET		hits = '".$instructions->val."'
	    WHERE 	template_id	  =  ".$instructions->template_id;
	    
	    $this->DB->query($sql);
    	
    	$this->data["success"] = True;
    }  
    
	function api_set_type($instructions) 
    {    	
	    if($type=="feed") $type = "rss";
	    
	    $sql = "
	    UPDATE 	exp_templates
	    SET		template_type = '".$instructions->val."'
	    WHERE 	template_id	  =  ".$instructions->template_id;
	    
	    $this->DB->query($sql);
    	    	
    	$this->data["success"] = True;
    }    
    
    function api_set_php($instructions) 
   	{
    	switch($instructions->val)
    	{
	    	case "off":
	    		$data = "SET allow_php = 'n'";
	    		break;
    		case "output":
    			$data = "SET allow_php = 'y', php_parse_location = 'o'"; 
    			break;
    		case "input":
    			$data = "SET allow_php = 'y', php_parse_location = 'i'"; 
    			break;
    	}
    	
    	$sql = "
    	UPDATE 	exp_templates
    	$data
    	WHERE 	template_id	  =  ".$instructions->template_id;
    	
    	$this->DB->query($sql);
    	
    	$this->data["success"] = True;
   	}
   	
    function api_set_caching($instructions) 
   	{
    	if($instructions->val=="0")
    	{
    		$data = "SET cache = 'n'";
    	} else
    	{
    		$data = "SET cache = 'y', refresh = ".$instructions->val;
    	}
    	
  		$sql = "
  		UPDATE 	exp_templates
  		$data
  		WHERE 	template_id	  =  ".$instructions->template_id;
  		
  		$this->DB->query($sql);
    	
    	$this->data["success"] = True;
   	}
    
    ///! Templates
    function list_templates_for_group()
    {
    	$group_id = $this->input->GBL('group_id');
		// Get the templates for each group
		$sql = "SELECT 	t.template_id,
						t.group_id,
						t.template_name,
						t.template_type,
						t.edit_date,
						t.cache,
						t.refresh,
						t.allow_php,
						t.php_parse_location,
						t.hits,
						t.template_data
				FROM	exp_templates t 
				JOIN	exp_template_groups g 	ON g.group_id = t.group_id
				WHERE	g.site_id = ".$this->DEFAULT_SITE_ID."
				AND		g.group_id = ".$group_id;
				
		$template_query = $this->DB->query($sql); 
		$results = $template_query->result;			
			
		$this->data["templates"] = array();
		
		foreach($results as $template) 
		{
		
			$template = (object)$template;
			
		  $template_filename = $template->template_name; 
		  
			$this->data["templates"][$template_filename] = array(	"id" 				=> (int)$template->template_id,
									"name" 				=> $template->template_name,
									"type"				=> $template->template_type,
									"last_modified" 	=> (int)$template->edit_date,
									"should_cache"  	=> (bool)($template->cache =="y"),
									"cache_refresh"		=> (int)$template->refresh,										
									"allow_php"  		=> (bool)($template->allow_php =="y"),
									"php_parse_output"	=> (bool)($template->php_parse_location =="o"),												
									"hits"				=> (int)$template->hits,
									"data"				=> base64_encode($template->template_data)
								);
		}
				
		$this->data["success"] = True;
	}
	
    function api_delete_template($instructions)
    {    	
		$this->DB->query("DELETE from exp_templates where template_id = ".$instructions->template_id);
    	$this->data["success"] = $this->DB->affected_rows != 0;
    	$this->functions->clear_caching('all');
    }
    
    function api_move_template($instructions)
    {
	  	$sql = "
	  	UPDATE 	exp_templates
	  	SET		group_id 		=	".$instructions->group_id.",
	  			edit_date 		=	".$this->localization->now.",
	  			last_author_id	= 	".$this->session->userdata['member_id']."
	  	WHERE	template_id		=	".$instructions->template_id;
	  	
		$this->DB->query($sql);
				
		$this->functions->clear_caching('all');

		$this->data["success"] = True;
    }

    function api_rename_template($instructions)
    {
    	$andType = $instructions->type;
    	
    	if($andType=="feed") $andType = "rss";
    	
		$sql = "
			UPDATE 	exp_templates
			SET		template_name 		=	'".$this->escape_str($instructions->name)."',
					edit_date 			=	".$this->localization->now.",
					template_type		=	'".$andType."',
					last_author_id		= 	".$this->session->userdata['member_id']."
			WHERE	template_id			=	".$instructions->template_id;
	
		$this->DB->query($sql);    
			
		$this->functions->clear_caching('all');
		
		$this->data["success"] = True;
    }

    function api_create_template($instructions) 
   	{
   		$template_type = $instructions->type;
   		
   		if($template_type=="feed") $template_type = "rss";
   		
   		$data = array(	'site_id' 			=> $this->DEFAULT_SITE_ID,
    					'group_id' 			=> $instructions->group_id,
    					'template_name'		=> $instructions->name,
						"edit_date"			=> $this->localization->now,
						"last_author_id" 	=> $this->session->userdata['member_id'],
						"template_type"		=> $template_type);
    	
    	$this->DB->query($this->_build_insert($data,'exp_templates'));
    	
    	$this->data["success"] = True;
    	
    	$this->_template_data($this->DB->insert_id);
   	}

	function api_update_template($instructions)
    {		
		$data = str_replace("\\","",$instructions->template_data);
		$data = str_replace(" ","+",$data);		
		$decoded = base64_decode($data);
		
		//	 Save revision cache 
		if ($this->preferences->ini('save_tmpl_revisions')=='y' && strlen($decoded))  // If the update blanks it out, don't bother saving a revision.
		{
			$revision = array(
							'item_id'			=> $instructions->id,
							'item_table'		=> 'exp_templates',
							'item_field'		=> 'template_data',
							'item_data'			=> $this->escape_str($decoded),
							'item_date'			=> $this->localization->now,
							'item_author_id'	=> $this->session->userdata['member_id']
						 );
			
			$this->DB->query($this->_build_insert($revision,'exp_revision_tracker'));
		}
	
		$sql = "
		UPDATE 	exp_templates
		SET		template_data 	=	'".$this->escape_str($decoded)."',
				edit_date		= 	".$this->localization->now.",
				last_author_id	=	".$this->session->userdata['member_id']."
		WHERE	template_id		= 	".$instructions->id;
		
		
		$this->DB->query($sql);
		
		$this->functions->clear_caching('all');				
		
		$this->data["success"] = True;
		
		$this->_template_data($instructions->id);
    }
    
    function read_template_data()
    {
    	$this->_template_data($this->input->GBL('template_id'));
    }
    
    function _template_data($template_id)
    {
    	$sql = "SELECT 	t.template_id,
						t.group_id,
						t.template_name,
						t.template_type,
						t.template_data,
						t.edit_date,
						t.cache,
						t.refresh,
						t.allow_php,
						t.php_parse_location,
						t.hits
				FROM	exp_templates t 
				WHERE	t.site_id = ".$this->DEFAULT_SITE_ID."
				AND		t.template_id = ".$this->escape_str($template_id);

		$query = $this->DB->query($sql); 	
		
		if($query->num_rows==0)
		{
			$this->data["template"] = False;
			$this->data["success"] = False;			
		} 
		
		else 
		{			
			$template = (object)$query->result[0];
			
			$this->data["template"] = array("id" 				=> (int)$template->template_id,
											"group_id" 			=> (int)$template->group_id,
											"name" 				=> $template->template_name,
											"type"				=> $template->template_type,
											"last_modified" 	=> (int)$template->edit_date,
											"should_cache"  	=> (bool)($template->cache =="y"),
											"cache_refresh"		=> (int)$template->refresh,
											"allow_php"  		=> (bool)($template->allow_php =="y"),
											"php_parse_output"	=> (bool)($template->php_parse_location =="o"),												
											"hits"				=> (int)$template->hits,
											"data"				=> base64_encode($template->template_data)
											);	
			$this->data["success"] = True;											
		}
    }
    
    
    ///! Groups
    function list_groups()
    {
    	$sql = "SELECT 	group_id,
						group_name, 
						is_site_default
				FROM 	exp_template_groups
				WHERE	site_id = ".$this->DEFAULT_SITE_ID;

		$group_query = $this->DB->query($sql); 
		$groups = $group_query->result;
			
		$this->data["groups"] = array();
		
		foreach($groups as $group_arr)
		{
			$group = (object)$group_arr;
			
			$this->data["groups"][] = array("id" => (int)$group->group_id,
											"name" => $group->group_name);
			

			if($group->is_site_default=="y")
			{
				$this->data["index"] = (int)$group->group_id;
			}
		}

		$this->data["success"] = True;
    }
    
	function api_set_site_default($instructions)
 	{ 		
 		$sql = "
 		UPDATE 	exp_template_groups
 		SET		is_site_default = 'n'";

		$this->DB->query($sql);

		$sql = "
		UPDATE 	exp_template_groups
		SET		is_site_default = 'y'
		WHERE	group_id = ".$instructions->group_id;

		$this->DB->query($sql);
		
		$this->data["success"] = True;
 	}  

    function api_delete_group($instructions) 
   	{
   		$this->DB->query("DELETE FROM exp_templates 		WHERE group_id = ".$instructions->group_id);
   		$this->DB->query("DELETE FROM exp_template_groups 	WHERE group_id = ".$instructions->group_id);
    	$this->data["success"] = $this->DB->affected_rows != 0;
    	$this->functions->clear_caching('all');
   	}
    
    function api_create_group($instructions) 
   	{
   		
   		$q = $this->DB->query("SELECT MAX(group_order)+1 as group_order from exp_template_groups");
   		
   		$group_order  = $q->result[0]["group_order"];

		$data = array(	'site_id'			=> $this->DEFAULT_SITE_ID,
						'group_name'		=> $instructions->group_name,
						'group_order'		=> $group_order,
						'is_site_default' 	=> 'n');
						
		$this->DB->query($this->_build_insert($data,"exp_template_groups"));						
		
		$this->data["group_id"] = $this->DB->insert_id;
		$this->data["success"] = True;									
   	}

	function api_rename_group($instructions) 
	{
   		$sql = "
   		UPDATE 	exp_template_groups
   		SET		group_name 	= '".$this->escape_str($instructions->new_name)."'
   		WHERE	group_id	= ".$instructions->group_id;
   		
   		$this->DB->query($sql);   		
   		
   		$this->functions->clear_caching('all');
   		
   		$this->data["success"] = True;
   	}
}

?>