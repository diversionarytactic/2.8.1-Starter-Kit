<?php 

class EE1_Cocoa {
	var $EE_VERSION		 = 1;  
	
	// Author & Copyright: Padraig Kennedy, June 2011.
	
	// This is distributed as a component to an app and may only be used 
	// as intended by the app.  Please contact me at padraig.kennedy@gmail.com 
	// if you would like to discuss using it for any other purpose.
	
	// This abstract superclass should be subclassed to customise it for 
	// the app that will communicate with it.
	
	// The 'api' class is called with a post variable named 'data' containing
	// a json object that includes a 'command' variable.
	// Whatever is in the command variable will be called in the subclass with 
	// an 'api' prefix.
	
	// E.G.  {'command':'status'} would call $this->api_status($json_request)
	// api_status would be defined in the subclass.
	// Any data to be returned should be added to the $this->data[] array.
	// This array will be translated to JSON and outputted once the command 
	// function call finishes.
	
	function EE1_Cocoa()
	{
		$this->starttime = microtime(true);
    	$this->data = array("version"=>$this->VERSION);    	
    	
    	global $SESS, $DB, $IN, $PREFS, $FNS, $LOC;
    	
    	$this->session = $SESS;
    	$this->DB = $DB;
    	$this->input = $IN;
    	$this->preferences = $PREFS;
    	$this->functions = $FNS;
    	$this->localization = $LOC;
    	
    	if ( !function_exists('json_decode'))			// PHP 4 doesn't have decode_json()
		{
			$pathinfo = pathinfo(__FILE__);     
			include_once $pathinfo['dirname']."/Services_json.php";
		}
		
	}
	
	function _start()
	{
		$this->data["logged_in"] 		= $this->session->userdata['session_id']	== "0" ? FALSE:TRUE;
			$this->data["is_admin"]			= $this->_is_authorised();
		$this->data["session_id"]		= $this->session->userdata['session_id'];
		
		if(!$this->data["is_admin"]) 	// bail if we're not logged in as superadmins
		{
			if($this->data["responding_to_command"]=="status")
			{       
				$this->data["site_label"] = $this->preferences->ini('site_label');  
			   	$this->data["success"] = True;      
			
			} else
			{
				$this->data["success"] = False;
			}
				
			$this->_finish();
		}	

		
	}
	   
    function _finish()
    {
    	$this->data["response_time"] = round((microtime(true) - $this->starttime),5);
    	$this->data["ee_version"] = $this->EE_VERSION;
    	
    	//send back an XID to use for the next request.
    	$this->data["XID"] = $this->xid();
    	$this->data["site_name"] = $this->preferences->ini('site_short_name');
    	
    	echo $this->generate_json($this->data, true);	
    	
    	die(); // DO NOT REMOVE THIS! 
    }

  	function _is_authorised()
    {
    	return $this->session->userdata['group_id'] == 1;
    }

	
     
    function xid()
    {
    	$hash = $this->functions->random('encrypt');
    	
    	$this->DB->query("	INSERT INTO exp_security_hashes (date, ip_address, hash)
    							VALUES (UNIX_TIMESTAMP(), '".$this->input->IP."', '".$hash."')");		
    	
    	return $hash;
    }
    
    function api()	
    {
    	$this->_start();
    		
		$instructions = (object)json_decode(stripslashes($this->input->GBL('data','POST')));
		
		$this->data["responding_to_command"] = @$instructions->command;
		
		if($this->data["responding_to_command"]=="")
		{
			echo "The Module is installed.";
			die();
		}
		
    	$command = "api_".$this->data["responding_to_command"];
    	
    	$this->$command($instructions);
    	
    	$this->_finish($instructions);
    }
    
    function api_logout()
    {
        $this->DB->query("DELETE FROM exp_online_users WHERE ip_address = '{$this->input->IP}' AND member_id = '".$this->escape_str($this->session->userdata('member_id'))."'");

        $this->DB->query("DELETE FROM exp_sessions WHERE session_id = '".$this->escape_str($this->session->userdata['session_id'])."'");
                
		$this->functions->set_cookie($this->session->c_uniqueid);       
		$this->functions->set_cookie($this->session->c_password);   
		$this->functions->set_cookie($this->session->c_session);   
		$this->functions->set_cookie($this->session->c_expire);   
		$this->functions->set_cookie($this->session->c_anon);   
        $this->functions->set_cookie('read_topics');  
        $this->functions->set_cookie('tracker');  
	
		$this->data["success"] = TRUE;
		
		return $this->_finish();
    }
    
    function log_item($msg)
    {
    	/*$pathinfo = pathinfo(__FILE__); 
    	$filename =  $pathinfo['dirname'].'/logs/'.'log-'.date('Y-m-d').'.log';
    		
		if ( ! $fp = @fopen($filename, 'wb'))
		{
			return FALSE;
		}
		$message = '';
		$message .= date('Y-m-d H:i:s'). ' --> '.$msg."\n";

		flock($fp, LOCK_EX);
		fwrite($fp, $message);
		flock($fp, LOCK_UN);
		fclose($fp);*/

    }
    
    function generate_json($result = NULL, $match_array_type = FALSE)
	{
		// JSON data can optionally be passed to this function
		// either as a database result object or an array, or a user supplied array
		if ( ! is_null($result))
		{
			if (is_object($result))
			{
				$json_result = $result->result_array();
			}
			elseif (is_array($result))
			{
				$json_result = $result;
			}
			else
			{
				return $this->_prep_args($result);
			}
		}
		else
		{
			return 'null';
		}
	
		$json = array();
		$_is_assoc = TRUE;
	
		if ( ! is_array($json_result) AND empty($json_result))
		{
			show_error("Generate JSON Failed - Illegal key, value pair.");
		}
		elseif ($match_array_type)
		{
			$_is_assoc = $this->_is_associative_array($json_result);
		}
	
		foreach ($json_result as $k => $v)
		{
			if ($_is_assoc)
			{
				$json[] = $this->_prep_args($k, TRUE).':'.$this->generate_json($v, $match_array_type);
			}
			else
			{
				$json[] = $this->generate_json($v, $match_array_type);
			}
		}
	
		$json = implode(',', $json);
	
		return $_is_assoc ? "{".$json."}" : "[".$json."]";
	
	}

	function _is_associative_array($arr)
	{
		foreach (array_keys($arr) as $key => $val)
		{
			if ($key !== $val)
			{
				return TRUE;
			}
		}

		return FALSE;
	}

	function _prep_args($result, $is_key = FALSE)
	{
		if (is_null($result))
		{
			return 'null';
		}
		elseif (is_bool($result))
		{
			return ($result === TRUE) ? 'true' : 'false';
		}
		elseif (is_string($result) OR $is_key)
		{
			return '"'.str_replace(array('\\', "\t", "\n", "\r", '"'), array('\\\\', '\\t', '\\n', "\\r", '\"'), $result).'"';
		}
		elseif (is_scalar($result))
		{
			return $result;
		}
	}

	function _build_insert($data,$table)
	{
		$cols = " (";
		$vals = " (";
		$first = True;
		
		foreach($data as $column=>$value)
		{
			$first ? $comma = " " : $comma = " ,";
			$first = False;
			
			$cols .= $comma.$column;	
			$vals .= $comma."'".$value."'";
		}
		$cols .= ")";
		$vals .= ")"; 
		
		return "INSERT INTO ".$table.$cols." VALUES ".$vals;
	}
	
	function escape_str($str, $like = FALSE)
	{
		// the EE1 version of this function stips slashes incorrectly.
		
		if (is_array($str))
		{
			foreach($str as $key => $val)
			{
				$str[$key] = $this->escape_str($val, $like);
			}

			return $str;
		}

		if (function_exists('mysql_real_escape_string') AND is_resource($this->DB->conn_id))
		{
			$str = mysql_real_escape_string($str, $this->DB->conn_id);
		}
		elseif (function_exists('mysql_escape_string'))
		{
			$str = mysql_escape_string($str);
		}
		else
		{
			$str = addslashes($str);
		}

		// escape LIKE condition wildcards
		if ($like === TRUE)
		{
			$str = str_replace(array('%', '_'), array('\\%', '\\_'), $str);
		}

		return $str;
	}

}

?>