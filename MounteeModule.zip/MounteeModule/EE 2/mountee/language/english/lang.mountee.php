<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');     

$lang = array( 

'mountee_module_name'				=> 'Mountee',
'mountee_module_description'		=> 'Enables the Mountee interface to ExpressionEngine'

);

 ?>