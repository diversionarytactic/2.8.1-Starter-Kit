<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');     

Class Mountee {
	function Mountee()
    {
		
    }
}

?>